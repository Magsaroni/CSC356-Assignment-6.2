<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mars Countdown</title>
</head>
<body>
    <div id="counter">Countdown</div>

    <!-- php code to get launch date n' time -->
    <?php
    $dateTime = strtotime(datetime: 'November 22, 2024 10:00:00');
    $unixDateTime = date("F d, Y H:i:s", $dateTime)
    ?>

    <!-- JS Code to run a countdown on the page -->
    <script>
        // use the time we defined in the php code and assign it to a JS Variable
    var countDownTimer = new Date("<?php echo "$unixDateTime"; ?>").getTime();

    console.log("countDownTimer=" + countDownTimer);

        var intervalId =setInterval(function(){
            // get the current time
            var currentTime = new Date().getTime();

            console.log("currentTime= " + currentTime);

            var timeDiff = countDownTimer - currentTime;

            const MS_IN_A_SECOND = 1000;
            const MS_IN_A_MINUTE = MS_IN_A_SECOND * 60;
            const MS_IN_AN_HOUR = MS_IN_A_MINUTE * 60;
            const MS_IN_A_DAY = MS_IN_AN_HOUR * 24;

            var days= Math.floor(timeDiff / MS_IN_A_DAY);
            var hours = Math.floor((timeDiff % MS_IN_A_DAY) / MS_IN_AN_HOUR);
            var minutes = Math.floor((timeDiff % MS_IN_AN_HOUR) / MS_IN_A_MINUTE);
            var seconds = Math.floor((timeDiff % MS_IN_A_MINUTE) / MS_IN_A_SECOND);

            document.getElementById("counter").innerHTML = days + " Days, " + hours " Hours, " + minutes + " Minutes, " + seconds + " Seconds ";


            if (days < 0){
                clearInterval(intervalId);
                document.getElementById("counter").innerHTML = "Sorry, you missed the launch!";
            }

            else if (days < 14){
                document.getElementById("counter").innerHTML += "<br>Pack your bags!";

            }
            else{
                document.getElementById("counter").innerHTML += <br>"Keep watchin' the countdown!";
            }
        }, 1000); // 1000 miliseconds is one second.
        </script>
</body>
</html>